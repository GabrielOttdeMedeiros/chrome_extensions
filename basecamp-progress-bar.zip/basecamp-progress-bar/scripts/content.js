// ==UserScript==
// @name         Basecamp Progress Bar
// @version      1.0
// @description  Adds a rectangular progress bar to the bottom of Basecamp cards based on steps progress
// @author       You
// @match        *://*.basecamp.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Set delay in milliseconds
    const delayInMilliseconds = 1;

    setTimeout(() => {
        function addProgressBars() {
            document.querySelectorAll('.kanban-card').forEach(card => {
                // Check if the card already has a progress bar
                if (card.querySelector('.progress-bar')) return;

                const stepsDiv = card.querySelector('.kanban-card__steps');

                if (stepsDiv) {
                    // Get progress data from kanban-card__steps
                    const stepsText = stepsDiv.textContent.trim();
                    const match = stepsText.match(/(\d+)\/(\d+)/);

                    if (match) {
                        const completed = parseInt(match[1], 10);
                        const total = parseInt(match[2], 10);
                        const progress = (completed / total) * 100;

                        // Create progress bar container
                        const progressBarContainer = document.createElement('div');
                        progressBarContainer.className = 'progress-bar';
                        progressBarContainer.style.width = '100%';
                        progressBarContainer.style.backgroundColor = '#26343b';
                        progressBarContainer.style.borderRadius = '0';
                        progressBarContainer.style.height = '6px';  // Adjust height as needed
                        progressBarContainer.style.position = 'absolute';
                        progressBarContainer.style.bottom = '0';
                        progressBarContainer.style.left = '0';

                        // Inner bar showing actual progress
                        const progressInner = document.createElement('div');
                        progressInner.style.width = `${progress}%`;
                        progressInner.style.height = '100%';
                        progressInner.style.backgroundColor = '#4caf50';

                        // Append inner bar to the outer progress bar container
                        progressBarContainer.appendChild(progressInner);

                        // Set the kanban card position to relative to anchor the progress bar
                        card.style.position = 'relative';

                        // Append progress bar to the kanban card
                        card.appendChild(progressBarContainer);
                    }
                }
            });
        }

        // Run addProgressBars initially and on a repeated interval indefinitely
        addProgressBars();
        setInterval(addProgressBars, 1); // Run every 2 seconds to handle new kanban cards

    }, delayInMilliseconds); // Delay execution by specified milliseconds
})();
